$(window).scroll(function(){
	console.log($(this).scrollTop());
	if($(this).scrollTop() >= 65){
		$("header").css("background","rgba(210, 47, 37, 0.9)");
	}else{
		$("header").css("background","");
	}
	var y = (200 / 566)*$(this).scrollTop();
	$(".wrap").css("background-position-y",y+'px');
})
